<?php

namespace Webkul\SocialLogin\Contracts;

interface CustomerSocialAccount
{
}