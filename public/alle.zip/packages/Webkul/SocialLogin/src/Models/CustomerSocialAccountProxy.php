<?php

namespace Webkul\SocialLogin\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CustomerSocialAccountProxy extends ModelProxy
{

}