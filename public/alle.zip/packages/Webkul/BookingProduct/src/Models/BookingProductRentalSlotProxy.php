<?php

namespace Webkul\BookingProduct\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BookingProductRentalSlotProxy extends ModelProxy
{

}