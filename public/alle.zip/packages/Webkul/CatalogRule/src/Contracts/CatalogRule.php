<?php

namespace Webkul\CatalogRule\Contracts;

interface CatalogRule
{
}