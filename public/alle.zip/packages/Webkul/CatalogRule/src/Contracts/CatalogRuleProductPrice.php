<?php

namespace Webkul\CatalogRule\Contracts;

interface CatalogRuleProductPrice
{
}