<?php

namespace Webkul\CatalogRule\Contracts;

interface CatalogRuleProduct
{
}