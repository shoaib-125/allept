<?php

namespace Webkul\CatalogRule\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CatalogRuleProductPriceProxy extends ModelProxy
{

}
