<?php

namespace Webkul\CMS\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CmsPageProxy extends ModelProxy
{

}