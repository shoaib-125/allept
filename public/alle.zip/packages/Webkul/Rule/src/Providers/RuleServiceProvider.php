<?php

namespace Webkul\Rule\Providers;

use Illuminate\Support\ServiceProvider;

class RuleServiceProvider extends ServiceProvider
{
}