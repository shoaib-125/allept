<?php

 return [
    'name'    => 'Webkul Bagisto Product',
    'version' => '0.0.1',
 ];
