<?php

namespace Webkul\Product\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ProductReviewProxy extends ModelProxy
{

}