<?php

namespace Webkul\Product\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ProductBundleOptionProductProxy extends ModelProxy
{

}