<?php

return [
    'enter-attribute' => ':attribute Giriniz',
    'select-attribute' => ':attribute Seçiniz'
];
