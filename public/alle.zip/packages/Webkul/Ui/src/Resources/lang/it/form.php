<?php

    return [
        'enter-attribute' => 'Inserisci :attribute',
        'select-attribute' => 'Seleziona :attribute'
    ];