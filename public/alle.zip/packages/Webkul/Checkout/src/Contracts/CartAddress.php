<?php

namespace Webkul\Checkout\Contracts;

interface CartAddress
{
}