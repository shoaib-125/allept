<?php

namespace Webkul\Checkout\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartAddressProxy extends ModelProxy
{

}