<?php

namespace Webkul\Checkout\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartShippingRateProxy extends ModelProxy
{

}