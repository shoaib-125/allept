@extends('shop::layouts.master')

@section('page_title')
    Package UserManagement
@stop

@section('content-wrapper')

    <div class="main">
        Package UserManagement
    </div>

@stop