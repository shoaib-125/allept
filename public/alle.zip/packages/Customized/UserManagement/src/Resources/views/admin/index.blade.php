@extends('admin::layouts.master')

@section('page_title')
        Admin | User Management
@stop

@section('content-wrapper')

    <div class="content full-page dashboard">
        <div class="page-header">
            <div class="page-title">
                <h1>Package User Management</h1>
            </div>

            <div class="page-action">
            </div>
        </div>

        <div class="page-content">
        </div>
    </div>

@stop