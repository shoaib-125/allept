<?php

 return [
    'name'    => 'Webkul Bagisto User',
    'version' => '0.0.1'
 ];
