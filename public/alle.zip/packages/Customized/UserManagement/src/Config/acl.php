<?php

return [
    [
        'key' => 'usermanagement',
        'name' => 'User Management',
        'route' => 'usermanagement.admin.index',
        'sort' => 2
    ]
];