<?php

return [
    [
        'key' => 'usermanagement',
        'name' => 'User Management',
        'route' => 'usermanagement.admin.index',
        'sort' => 2,
        'icon-class' => 'customer-icon',
    ]
];